x = 2
if x >= 2:
    print(4)
